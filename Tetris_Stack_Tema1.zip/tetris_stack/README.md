
# Desafio Tetris Stack – Tema 1

Este projeto apresenta uma implementação completa de um **Tetris minimalista** utilizando Python e a biblioteca **Pygame**.

---

## 🎮 Descrição Completa

O *Tetris Stack – Tema 1* foi desenvolvido como parte de um desafio acadêmico, trazendo uma estrutura limpa, organizada e de fácil entendimento.  
O jogo contém:

### ✔ Sistema de peças baseado nas formas clássicas (I, O, T, L, J, S, Z)  
### ✔ Detecção de colisão precisa  
### ✔ Rotação das peças  
### ✔ Remoção de linhas completas  
### ✔ Geração procedural de peças  
### ✔ Mecânica fiel ao Tetris tradicional  
### ✔ Grade colorida e interface simples  

---

## 🧠 Funcionamento Interno

### **1. Representação das peças**
Cada peça é representada por uma matriz binária (`1 = bloco`, `0 = vazio`).  
As cores são atribuídas automaticamente com base na lista de formas.

### **2. Sistema de validação**
Uma função verifica se a peça:

- Está dentro do tabuleiro  
- Não sobrepõe outras peças  
- Não ultrapassa limites

### **3. Geração de novas peças**
Após uma peça se fixar no tabuleiro:

- As linhas são verificadas  
- Linhas completas são removidas  
- A nova peça é criada no topo  

### **4. Rotação**
A rotação é feita por transposição e reversão da matriz.

---

## 🚀 Como Rodar

### **1. Instale as dependências**
```bash
pip install pygame
```

### **2. Execute o jogo**
```bash
python main.py
```

---

## 📂 Estrutura do Projeto

```
tetris_stack/
│── main.py
│── README.md
```

---

## 📦 Arquivo ZIP

O ZIP gerado contém:

- `main.py`
- `README.md`

Pronto para ser enviado ao GitHub.

---

## ✨ Autor
Desenvolvido para fins acadêmicos.
